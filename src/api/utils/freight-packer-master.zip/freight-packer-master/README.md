# Freight Packer
Javascript API:
- Original 3D bin packing solver
- Visualization in webGL/three.js

![UI Mockup](https://raw.githubusercontent.com/chadiik/freight-packer/master/UIX/CargoScreen1.png)

+ UI mockup / UX design

Demo video: https://youtu.be/tQPdBg9_k-4
