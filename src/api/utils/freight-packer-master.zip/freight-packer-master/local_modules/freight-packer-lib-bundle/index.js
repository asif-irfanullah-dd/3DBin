const three91 = require('./lib/three/three-91');

module.exports = {
    THREE: three91
};