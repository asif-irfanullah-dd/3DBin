import EntryInputView from "./view/EntryInputView";

class Constants{
    constructor(){

    }

    static get scaleRefFigure(){ return EntryInputView.scaleFigure; }
}

export default Constants;