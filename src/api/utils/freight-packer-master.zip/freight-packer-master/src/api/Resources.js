
class Resources{
    constructor(){
        this.texturesPath = '';
    }
}

export default Resources;