
class Sequence{
    constructor(){
    }

    Chain()
}

export default Sequence;