const api = require('./FreightPacker').default;
window.FreightPacker = api;