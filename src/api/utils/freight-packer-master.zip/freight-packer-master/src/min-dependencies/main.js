/*
const scope = global;

scope.THREE = require('./lib/three/three-91');

require('./lib/three/controls/OrbitControls');
require('./lib/three/controls/TransformControls');
require('./lib/three/utils/BufferGeometryUtils');

scope.keypress = require('./lib/keypress');
*/