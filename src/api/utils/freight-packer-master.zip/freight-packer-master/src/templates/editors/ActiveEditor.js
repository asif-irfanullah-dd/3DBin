
class ActiveEditor {
    constructor(gui){
        this.folder;
    }

    Dispose(){

    }
}

export default ActiveEditor;