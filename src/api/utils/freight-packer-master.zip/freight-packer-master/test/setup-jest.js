import { THREE } from "freight-packer-lib-bundle";

global.THREE = THREE;