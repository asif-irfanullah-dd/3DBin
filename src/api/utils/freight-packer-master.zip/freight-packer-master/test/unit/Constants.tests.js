
export const Types = {
    Dimensions: 'Dimensions'
};

//it('Constants exports', ()=>{})